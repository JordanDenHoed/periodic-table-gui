package PeriodicTable;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PeriodicTable extends JFrame implements ActionListener{
	
		// Add buttons
		JButton hydrogen = new JButton("<html>1<br />H<br />1.00795</html>");
		JButton helium = new JButton("<html>2<br />He<br />4.00260</html>");
		JButton lithium = new JButton("<html>3<br />Li<br />6.9412</html>");
		JButton beryllium = new JButton("<html>4<br />Be<br />9.01218</html>");
		JButton boron = new JButton("<html>5<br />B<br />10.8117</html>");
		JButton carbon = new JButton("<html>6<br />C<br />12.0108</html>");
		JButton nitrogen = new JButton("<html>7<br />N<br />14.00674</html>");
		JButton oxygen = new JButton("<html>8<br />O<br />15.9994</html>");
		JButton flourine = new JButton("<html>9<br />He<br />18.9984</html>");
		JButton neon = new JButton("<html>10<br />Ne<br />20.1797</html>");
		JButton sodium = new JButton("<html>11<br />Na<br />22.9898</html>");
		JButton magnesium = new JButton("<html>12<br />Mg<br />24.3051</html>");
		JButton aluminum = new JButton("<html>13<br />Al<br />26.9815</html>");
		JButton silicon = new JButton("<html>14<br />Si<br />28.0855</html>");
		JButton phosphorus = new JButton("<html>15<br />P<br />30.9738</html>");
		JButton sulfur = new JButton("<html>16<br />S<br />32.0666</html>");
		JButton chlorine = new JButton("<html>17<br />Cl<br />35.4528</html>");
		JButton argon = new JButton("<html>18<br />Ar<br />39.948</html>");
		JButton potassium = new JButton("<html>19<br />P<br />39.0983</html>");
		JButton calcium = new JButton("<html>20<br />Ca<br />40.0784</html>");
		JButton scandium = new JButton("<html>21<br />Sc<br />44.9559</html>");
		JButton titanium = new JButton("<html>22<br />Ti<br />47.8761</html>");
		JButton vanadium = new JButton("<html>23<br />V<br />50.9415</html>");
		JButton chromium = new JButton("<html>24<br />Cr<br />51.9962</html>");
		JButton manganese = new JButton("<html>25<br />Mn<br />54.9380</html>");
		JButton iron = new JButton("<html>26<br />Fe<br />55.8452</html>");
		JButton cobalt = new JButton("<html>27<br />Co<br />58.9332</html>");
		JButton nickel = new JButton("<html>28<br />Ni<br />58.6934</html>");
		JButton copper = new JButton("<html>29<br />Cu<br />63.5463</html>");
		JButton zinc = new JButton("<html>30<br />Zn<br />65.392</html>");
		JButton gallium = new JButton("<html>31<br />Ga<br />69.723</html>");
		JButton germanium = new JButton("<html>32<br />Ge<br />72.612</html>");
		JButton arsenic = new JButton("<html>33<br />As<br />74.9216</html>");
		JButton selenium = new JButton("<html>34<br />Se<br />78.963</html>");
		JButton bromine = new JButton("<html>35<br />Br<br />79.904</html>");
		JButton krypton = new JButton("<html>36<br />Kr<br />83.801</html>");
		JButton rubidium = new JButton("<html>37<br />Rb<br />85.4678</html>");
		JButton strontium = new JButton("<html>38<br />Sr<br />87.621</html>");
		JButton yttrium = new JButton("<html>39<br />Y<br />88.9059</html>");
		JButton zirconium = new JButton("<html>40<br />Zr<br />91.2242</html>");
		JButton niobium = new JButton("<html>41<br />Nb<br />92.9064</html>");
		JButton molybdenum = new JButton("<html>42<br />Mo<br />95.941</html>");
		JButton technetium = new JButton("<html>43<br />Tc<br />(98)</html>");
		JButton ruthenium = new JButton("<html>44<br />Ru<br />101.072</html>");
		JButton rhodium = new JButton("<html>45<br />Rh<br />102.906</html>");
		JButton palladium = new JButton("<html>46<br />Pd<br />106.421</html>");
		JButton silver = new JButton("<html>47<br />Ag<br />107.868</html>");
		JButton cadmium = new JButton("<html>48<br />Cd<br />112.412</html>");
		JButton indium = new JButton("<html>49<br />In<br />114.818</html>");
		JButton tin = new JButton("<html>50<br />Sn<br />118.711</html>");
		JButton antimony = new JButton("<html>51<br />Sb<br />121.760</html>");
		JButton tellurium = new JButton("<html>52<br />Te<br />127.603</html>");
		JButton iodine = new JButton("<html>53<br />I<br />126.904</html>");
		JButton xenon = new JButton("<html>54<br />Xe<br />131.292</html>");
		JButton cesium = new JButton("<html>55<br />Cs<br />132.905</html>");
		JButton barium = new JButton("<html>56<br />Ba<br />137.328</html>");
		JButton lanthanum = new JButton("<html>57<br />La<br />139.906</html>");
		JButton cerium = new JButton("<html>58<br />Ce<br />140.116</html>");
		JButton praseodymium = new JButton("<html>59<br />Pr<br />140.908</html>");
		JButton neodymium = new JButton("<html>60<br />Nd<br />144.243</html>");
		JButton promethium = new JButton("<html>61<br />Pm<br />(145)</html>");
		JButton samarium = new JButton("<html>62<br />Sm<br />150.363</html>");
		JButton europium = new JButton("<html>63<br />Eu<br />151.964</html>");
		JButton gadolinium = new JButton("<html>64<br />Gd<br />157.253</html>");
		JButton terbium = new JButton("<html>65<br />Tb<br />158.925</html>");
		JButton dysprosium = new JButton("<html>66<br />Dy<br />162.503</html>");
		JButton holmium = new JButton("<html>67<br />Ho<br />164.930</html>");
		JButton erbium = new JButton("<html>68<br />Er<br />167.263</html>");
		JButton thulium = new JButton("<html>69<br />Tm<br />168.934</html>");
		JButton ytterbium = new JButton("<html>70<br />Yb<br />173.04</html>");
		JButton lutetium = new JButton("<html>71<br />Lu<br />174.967</html>");
		JButton hafnium = new JButton("<html>72<br />Hf<br />178.492</html>");
		JButton tantalum = new JButton("<html>73<br />Ta<br />180.948</html>");
		JButton tungsten = new JButton("<html>74<br />W<br />183.841</html>");
		JButton rhenium = new JButton("<html>75<br />Re<br />186.207</html>");
		JButton osmium = new JButton("<html>76<br />Os<br />190.233</html>");
		JButton iridium = new JButton("<html>77<br />Ir<br />192.217</html>");
		JButton platinum = new JButton("<html>78<br />Pt<br />195.078</html>");
		JButton gold = new JButton("<html>79<br />Au<br />196.967</html>");
		JButton mercury = new JButton("<html>80<br />Hg<br />200.592</html>");
		JButton thallium = new JButton("<html>81<br />Tl<br />204.383</html>");
		JButton lead = new JButton("<html>82<br />Pb<br />207.21</html>");
		JButton bismuth = new JButton("<html>83<br />Bi<br />208.980</html>");
		JButton polonium = new JButton("<html>84<br />Po<br />(209)</html>");
		JButton astatine = new JButton("<html>85<br />At<br />(210)</html>");
		JButton radon = new JButton("<html>86<br />Rn<br />(222)</html>");
		JButton francium = new JButton("<html>87<br />Fr<br />(223)</html>");
		JButton radium = new JButton("<html>88<br />Ra<br />(226)</html>");
		JButton actinium = new JButton("<html>89<br />Ac<br />(227)</html>");
		JButton thorium = new JButton("<html>90<br />Th<br />232.038</html>");
		JButton protactinium = new JButton("<html>91<br />Pa<br />231.036</html>");
		JButton uranium = new JButton("<html>92<br />U<br />238.029</html>");
		JButton neptunium = new JButton("<html>93<br />Np<br />(237)</html>");
		JButton plutonium = new JButton("<html>94<br />Pu<br />(244)</html>");
		JButton americium = new JButton("<html>95<br />Am<br />(243)</html>");
		JButton curium = new JButton("<html>96<br />Cm<br />(247)</html>");
		JButton berkelium = new JButton("<html>97<br />Bk<br />(247)</html>");
		JButton californium = new JButton("<html>98<br />Cf<br />(251)</html>");
		JButton einsteinium = new JButton("<html>99<br />Es<br />(252)</html>");
		JButton fermium = new JButton("<html>100<br />Fm<br />(257)</html>");
		JButton mendelevium = new JButton("<html>101<br />Md<br />(258)</html>");
		JButton nobelium = new JButton("<html>102<br />No<br />(259)</html>");
		JButton lawrencium = new JButton("<html>103<br />Lr<br />(262)</html>");
		JButton rutherfordium = new JButton("<html>104<br />Rf<br />(261)</html>");
		JButton dubnium = new JButton("<html>105<br />Db<br />(262)</html>");
		JButton seaborgium = new JButton("<html>106<br />Sg<br />(263)</html>");
		JButton bohrium = new JButton("<html>107<br />Bh<br />(262)</html>");
		JButton hassium = new JButton("<html>108<br />Hs<br />(265)</html>");
		JButton meitnerium = new JButton("<html>109<br />Mt<br />(266)</html>");
		JButton darmstadtium = new JButton("<html>110<br />Ds<br />(269)</html>");
		JButton roentgenium = new JButton("<html>111<br />Rg<br />(272)</html>");
		JButton copernicium = new JButton("<html>112<br />Cn<br />(285)</html>");
		JButton nihonium = new JButton("<html>113<br />Nh<br />(284)</html>");
		JButton flerovium = new JButton("<html>114<br />Fl<br />(289)</html>");
		JButton moscovium = new JButton("<html>115<br />Mc<br />(288)</html>");
		JButton livermorium = new JButton("<html>116<br />Lv<br />(292)</html>");
		JButton tennessine = new JButton("<html>117<br />Ts<br />(295)</html>");
		JButton oganesson = new JButton("<html>118<br />Og<br />(269)</html>");
		JButton filterElements = new JButton("<html><center>Filter<br />Elements</center></html>");
		
		// Create JFrame
		JFrame frame = new JFrame();
		
		// Create JPanel
		JPanel panel = new JPanel();
		
		// Initialize JOptionPane variables
		JFrame filterFrame = new JFrame();
		JPanel filterPanel = new JPanel();
		
		JTextField bpUpper = new JTextField(10);
		JTextField bpLower = new JTextField(10);
		JTextField mpUpper = new JTextField(10);
		JTextField mpLower = new JTextField(10);
		JTextField dUpper = new JTextField(10);
		JTextField dLower = new JTextField(10);
		JTextField eUpper = new JTextField(10);
		JTextField eLower = new JTextField(10);
		JTextField amUpper = new JTextField(10);
		JTextField amLower = new JTextField(10);
		
		JLabel bpuLabel = new JLabel("Highest boiling point");
		JLabel bplLabel = new JLabel("Lowest boiling point");
		JLabel mpuLabel = new JLabel("Highest melting point");
		JLabel mplLabel = new JLabel("Lowest melting point");
		JLabel duLabel = new JLabel("Highest density");
		JLabel dlLabel = new JLabel("Lowest density");
		JLabel euLabel = new JLabel("Highest electronegativity");
		JLabel elLabel = new JLabel("Lowest electronegativity");
		JLabel amuLabel = new JLabel("Highest atomic mass");
		JLabel amlLabel = new JLabel("Lowest atomic mass");
		
		JButton okButton = new JButton("OK");
		
		JTextArea resultText = new JTextArea(1,1);
		JScrollPane sp = new JScrollPane(resultText);
		
		GridBagConstraints c = new GridBagConstraints();
		
		// Database variables
		String jdbcUrl = "jdbc:sqlite:/C:\\Users\\jorda\\OneDrive\\Documents\\SQL Practice\\Elements.db";
		boolean dbAccessed = false;
		
		
		
	public PeriodicTable() {
		
		// Add colour to the buttons
		hydrogen.setBackground(Color.BLUE);
		helium.setBackground(Color.MAGENTA);
		lithium.setBackground(Color.ORANGE);
		beryllium.setBackground(Color.RED);
		boron.setBackground(Color.YELLOW);
		carbon.setBackground(Color.BLUE);
		nitrogen.setBackground(Color.BLUE);
		oxygen.setBackground(Color.BLUE);
		flourine.setBackground(Color.BLUE);
		neon.setBackground(Color.MAGENTA);
		sodium.setBackground(Color.ORANGE);
		magnesium.setBackground(Color.RED);
		aluminum.setBackground(Color.GREEN);
		silicon.setBackground(Color.YELLOW);
		phosphorus.setBackground(Color.BLUE);
		sulfur.setBackground(Color.BLUE);
		chlorine.setBackground(Color.BLUE);
		argon.setBackground(Color.MAGENTA);
		potassium.setBackground(Color.ORANGE);
		calcium.setBackground(Color.RED);
		scandium.setBackground(Color.CYAN);
		titanium.setBackground(Color.CYAN);
		vanadium.setBackground(Color.CYAN);
		chromium.setBackground(Color.CYAN);
		manganese.setBackground(Color.CYAN);
		iron.setBackground(Color.CYAN);
		cobalt.setBackground(Color.CYAN);
		nickel.setBackground(Color.CYAN);
		copper.setBackground(Color.CYAN);
		zinc.setBackground(Color.CYAN);
		gallium.setBackground(Color.GREEN);
		germanium.setBackground(Color.YELLOW);
		arsenic.setBackground(Color.YELLOW);
		selenium.setBackground(Color.BLUE);
		bromine.setBackground(Color.BLUE);
		krypton.setBackground(Color.MAGENTA);
		rubidium.setBackground(Color.ORANGE);
		strontium.setBackground(Color.RED);
		yttrium.setBackground(Color.CYAN);
		zirconium.setBackground(Color.CYAN);
		niobium.setBackground(Color.CYAN);
		molybdenum.setBackground(Color.CYAN);
		technetium.setBackground(Color.CYAN);
		ruthenium.setBackground(Color.CYAN);
		rhodium.setBackground(Color.CYAN);
		palladium.setBackground(Color.CYAN);
		silver.setBackground(Color.CYAN);
		cadmium.setBackground(Color.CYAN);
		indium.setBackground(Color.GREEN);
		tin.setBackground(Color.GREEN);
		antimony.setBackground(Color.YELLOW);
		tellurium.setBackground(Color.YELLOW);
		iodine.setBackground(Color.BLUE);
		xenon.setBackground(Color.MAGENTA);
		cesium.setBackground(Color.ORANGE);
		barium.setBackground(Color.RED);
		lanthanum.setBackground(Color.LIGHT_GRAY);
		cerium.setBackground(Color.LIGHT_GRAY);
		praseodymium.setBackground(Color.LIGHT_GRAY);
		neodymium.setBackground(Color.LIGHT_GRAY);
		promethium.setBackground(Color.LIGHT_GRAY);
		samarium.setBackground(Color.LIGHT_GRAY);
		europium.setBackground(Color.LIGHT_GRAY);
		gadolinium.setBackground(Color.LIGHT_GRAY);
		terbium.setBackground(Color.LIGHT_GRAY);
		dysprosium.setBackground(Color.LIGHT_GRAY);
		holmium.setBackground(Color.LIGHT_GRAY);
		erbium.setBackground(Color.LIGHT_GRAY);
		thulium.setBackground(Color.LIGHT_GRAY);
		ytterbium.setBackground(Color.LIGHT_GRAY);
		lutetium.setBackground(Color.LIGHT_GRAY);
		hafnium.setBackground(Color.CYAN);
		tantalum.setBackground(Color.CYAN);
		tungsten.setBackground(Color.CYAN);
		rhenium.setBackground(Color.CYAN);
		osmium.setBackground(Color.CYAN);
		iridium.setBackground(Color.CYAN);
		platinum.setBackground(Color.CYAN);
		gold.setBackground(Color.CYAN);
		mercury.setBackground(Color.CYAN);
		thallium.setBackground(Color.GREEN);
		lead.setBackground(Color.GREEN);
		bismuth.setBackground(Color.GREEN);
		polonium.setBackground(Color.GREEN);
		astatine.setBackground(Color.GREEN);
		radon.setBackground(Color.MAGENTA);
		francium.setBackground(Color.ORANGE);
		radium.setBackground(Color.RED);
		actinium.setBackground(Color.PINK);
		thorium.setBackground(Color.PINK);
		protactinium.setBackground(Color.PINK);
		uranium.setBackground(Color.PINK);
		neptunium.setBackground(Color.PINK);
		plutonium.setBackground(Color.PINK);
		americium.setBackground(Color.PINK);
		curium.setBackground(Color.PINK);
		berkelium.setBackground(Color.PINK);
		californium.setBackground(Color.PINK);
		einsteinium.setBackground(Color.PINK);
		fermium.setBackground(Color.PINK);
		mendelevium.setBackground(Color.PINK);
		nobelium.setBackground(Color.PINK);
		lawrencium.setBackground(Color.PINK);
		rutherfordium.setBackground(Color.CYAN);
		dubnium.setBackground(Color.CYAN);
		seaborgium.setBackground(Color.CYAN);
		bohrium.setBackground(Color.CYAN);
		hassium.setBackground(Color.CYAN);
		meitnerium.setBackground(Color.GRAY);
		darmstadtium.setBackground(Color.GRAY);
		roentgenium.setBackground(Color.GRAY);
		copernicium.setBackground(Color.GRAY);
		nihonium.setBackground(Color.GRAY);
		flerovium.setBackground(Color.GRAY);
		moscovium.setBackground(Color.GRAY);
		livermorium.setBackground(Color.GRAY);
		tennessine.setBackground(Color.GRAY);
		oganesson.setBackground(Color.GRAY);
		
		// Border dimensions: top, bottom, left, right
		panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
		// Grid parameters: rows, columns, horizontal gap, vertical gap
		panel.setLayout(new GridLayout(0, 19));
		
		// Add buttons to panel
		// 1st row
		panel.add(hydrogen);
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(helium);
		
		// 2nd row
		panel.add(lithium);
		panel.add(beryllium);
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(boron);
		panel.add(carbon);
		panel.add(nitrogen);
		panel.add(oxygen);
		panel.add(flourine);
		panel.add(neon);
		
		// 3rd row
		panel.add(sodium);
		panel.add(magnesium);
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(aluminum);
		panel.add(silicon);
		panel.add(phosphorus);
		panel.add(sulfur);
		panel.add(chlorine);
		panel.add(argon);
		
		// 4th row
		panel.add(potassium);
		panel.add(calcium);
		panel.add(scandium);
		panel.add(new JLabel(""));
		panel.add(titanium);
		panel.add(vanadium);
		panel.add(chromium);
		panel.add(manganese);
		panel.add(iron);
		panel.add(cobalt);
		panel.add(nickel);
		panel.add(copper);
		panel.add(zinc);
		panel.add(gallium);
		panel.add(germanium);
		panel.add(arsenic);
		panel.add(selenium);
		panel.add(bromine);
		panel.add(krypton);
		
		// 5th row
		panel.add(rubidium);
		panel.add(strontium);
		panel.add(yttrium);
		panel.add(new JLabel(""));
		panel.add(zirconium);
		panel.add(niobium);
		panel.add(molybdenum);
		panel.add(technetium);
		panel.add(ruthenium);
		panel.add(rhodium);
		panel.add(palladium);
		panel.add(silver);
		panel.add(cadmium);
		panel.add(indium);
		panel.add(tin);
		panel.add(antimony);
		panel.add(tellurium);
		panel.add(iodine);
		panel.add(xenon);
		
		// 6th row
		panel.add(cesium);
		panel.add(barium);
		panel.add(lanthanum);
		panel.add(new JLabel(""));
		panel.add(hafnium);
		panel.add(tantalum);
		panel.add(tungsten);
		panel.add(rhenium);
		panel.add(osmium);
		panel.add(iridium);
		panel.add(platinum);
		panel.add(gold);
		panel.add(mercury);
		panel.add(thallium);
		panel.add(lead);
		panel.add(bismuth);
		panel.add(polonium);
		panel.add(astatine);
		panel.add(radon);
		
		// 7th row
		panel.add(francium);
		panel.add(radium);
		panel.add(actinium);
		panel.add(new JLabel(""));
		panel.add(rutherfordium);
		panel.add(dubnium);
		panel.add(seaborgium);
		panel.add(bohrium);
		panel.add(hassium);
		panel.add(meitnerium);
		panel.add(darmstadtium);
		panel.add(roentgenium);
		panel.add(copernicium);
		panel.add(nihonium);	
		panel.add(flerovium);
		panel.add(moscovium);
		panel.add(livermorium);
		panel.add(tennessine);
		panel.add(oganesson);
		
		// Gap row
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		
		// 8th row
		panel.add(new JLabel(""));
		panel.add(filterElements);
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(cerium);
		panel.add(praseodymium);
		panel.add(neodymium);
		panel.add(promethium);
		panel.add(samarium);
		panel.add(europium);
		panel.add(gadolinium);
		panel.add(terbium);
		panel.add(dysprosium);
		panel.add(holmium);
		panel.add(erbium);
		panel.add(thulium);
		panel.add(ytterbium);
		panel.add(lutetium);
		panel.add(new JLabel(""));
		
		// 9th row
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(new JLabel(""));
		panel.add(thorium);
		panel.add(protactinium);
		panel.add(uranium);
		panel.add(neptunium);
		panel.add(plutonium);
		panel.add(americium);
		panel.add(curium);
		panel.add(berkelium);
		panel.add(californium);
		panel.add(einsteinium);
		panel.add(fermium);
		panel.add(mendelevium);
		panel.add(nobelium);
		panel.add(lawrencium);
		panel.add(new JLabel(""));
		
		// Add panel to frame
		frame.add(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Periodic Table of the Elements");
		frame.pack();
		frame.setVisible(true);
		frame.setSize(1200,800);
		
		// Add action listeners
		hydrogen.addActionListener(this);
		helium.addActionListener(this);
		lithium.addActionListener(this);
		beryllium.addActionListener(this);
		boron.addActionListener(this);
		carbon.addActionListener(this);
		nitrogen.addActionListener(this);
		oxygen.addActionListener(this);
		flourine.addActionListener(this);
		neon.addActionListener(this);
		sodium.addActionListener(this);
		magnesium.addActionListener(this);
		aluminum.addActionListener(this);
		silicon.addActionListener(this);
		phosphorus.addActionListener(this);
		sulfur.addActionListener(this);
		chlorine.addActionListener(this);
		argon.addActionListener(this);
		potassium.addActionListener(this);
		calcium.addActionListener(this);
		scandium.addActionListener(this);
		titanium.addActionListener(this);
		vanadium.addActionListener(this);
		chromium.addActionListener(this);
		manganese.addActionListener(this);
		iron.addActionListener(this);
		cobalt.addActionListener(this);
		nickel.addActionListener(this);
		copper.addActionListener(this);
		zinc.addActionListener(this);
		gallium.addActionListener(this);
		germanium.addActionListener(this);
		arsenic.addActionListener(this);
		selenium.addActionListener(this);
		bromine.addActionListener(this);
		krypton.addActionListener(this);
		rubidium.addActionListener(this);
		strontium.addActionListener(this);
		yttrium.addActionListener(this);
		zirconium.addActionListener(this);
		niobium.addActionListener(this);
		molybdenum.addActionListener(this);
		technetium.addActionListener(this);
		ruthenium.addActionListener(this);
		rhodium.addActionListener(this);
		palladium.addActionListener(this);
		silver.addActionListener(this);
		cadmium.addActionListener(this);
		indium.addActionListener(this);
		tin.addActionListener(this);
		antimony.addActionListener(this);
		tellurium.addActionListener(this);
		iodine.addActionListener(this);
		xenon.addActionListener(this);
		cesium.addActionListener(this);
		barium.addActionListener(this);
		lanthanum.addActionListener(this);
		cerium.addActionListener(this);
		praseodymium.addActionListener(this);
		neodymium.addActionListener(this);
		promethium.addActionListener(this);
		samarium.addActionListener(this);
		europium.addActionListener(this);
		gadolinium.addActionListener(this);
		terbium.addActionListener(this);
		dysprosium.addActionListener(this);
		holmium.addActionListener(this);
		erbium.addActionListener(this);
		thulium.addActionListener(this);
		ytterbium.addActionListener(this);
		lutetium.addActionListener(this);
		hafnium.addActionListener(this);
		tantalum.addActionListener(this);
		tungsten.addActionListener(this);
		rhenium.addActionListener(this);
		osmium.addActionListener(this);
		iridium.addActionListener(this);
		platinum.addActionListener(this);
		gold.addActionListener(this);
		mercury.addActionListener(this);
		thallium.addActionListener(this);
		lead.addActionListener(this);
		bismuth.addActionListener(this);
		polonium.addActionListener(this);
		astatine.addActionListener(this);
		radon.addActionListener(this);
		francium.addActionListener(this);
		radium.addActionListener(this);
		actinium.addActionListener(this);
		thorium.addActionListener(this);
		protactinium.addActionListener(this);
		uranium.addActionListener(this);
		neptunium.addActionListener(this);
		plutonium.addActionListener(this);
		americium.addActionListener(this);
		curium.addActionListener(this);
		berkelium.addActionListener(this);
		californium.addActionListener(this);
		einsteinium.addActionListener(this);
		fermium.addActionListener(this);
		mendelevium.addActionListener(this);
		nobelium.addActionListener(this);
		lawrencium.addActionListener(this);
		rutherfordium.addActionListener(this);
		dubnium.addActionListener(this);
		seaborgium.addActionListener(this);
		bohrium.addActionListener(this);
		hassium.addActionListener(this);
		meitnerium.addActionListener(this);
		darmstadtium.addActionListener(this);
		roentgenium.addActionListener(this);
		copernicium.addActionListener(this);
		nihonium.addActionListener(this);
		flerovium.addActionListener(this);
		moscovium.addActionListener(this);
		livermorium.addActionListener(this);
		tennessine.addActionListener(this);
		oganesson.addActionListener(this);
		filterElements.addActionListener(this);
	}

	public static void main(String[] args) {
		new PeriodicTable();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == filterElements) {
			displayElementFilter();
		}
		else if (e.getSource() == okButton) {
			elementFilter();
		}
		else {
			String s = ((JButton) e.getSource()).getText();
			
			accessDatabase(s);
		}
	}
	
	public void displayElementFilter() {
		
		filterPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
		filterPanel.setLayout(new GridLayout(13,2));
		filterFrame.add(filterPanel);
		filterFrame.setTitle("Element Filter");
		filterFrame.pack();
		filterFrame.setSize(500,500);

		filterPanel.add(bpuLabel);
		filterPanel.add(bpUpper);
		filterPanel.add(bplLabel);
		filterPanel.add(bpLower);
		filterPanel.add(mpuLabel);
		filterPanel.add(mpUpper);
		filterPanel.add(mplLabel);
		filterPanel.add(mpLower);
		filterPanel.add(duLabel);
		filterPanel.add(dUpper);
		filterPanel.add(dlLabel);
		filterPanel.add(dLower);
		filterPanel.add(euLabel);
		filterPanel.add(eUpper);
		filterPanel.add(elLabel);
		filterPanel.add(eLower);
		filterPanel.add(amuLabel);
		filterPanel.add(amUpper);
		filterPanel.add(amlLabel);
		filterPanel.add(amLower);
		
		filterPanel.add(new JLabel(""));
		filterPanel.add(new JLabel(""));
		
		filterPanel.add(okButton);
		okButton.addActionListener(this);
		filterPanel.add(sp);
		
		filterFrame.setVisible(true);
		
		elementFilter();
	}
	
	public void elementFilter() {
		
		String query = "SELECT atomic_number, name FROM elements WHERE ";
		
		if (!bpUpper.getText().isEmpty()) {
			if (!bpLower.getText().isEmpty()) {
				query += "(boiling_point BETWEEN " + bpLower.getText() + " AND " + bpUpper.getText() + ")";
			}
			else {
				query += "(boiling_point < " + bpUpper.getText() + ")";
			}
			dbAccessed = true;
		}
		else if (!bpLower.getText().isEmpty()) {
			query += "(boiling_point > " + bpLower.getText() + ")";
			dbAccessed = true;
			
		}
		if (!mpUpper.getText().isEmpty()) {
			if (dbAccessed) {
				query += " AND ";
			}
			if (!mpLower.getText().isEmpty()) {
				query += "(melting_point BETWEEN " + mpLower.getText() + " AND " + mpUpper.getText() + ")";
			}
			else {
				query += "(melting_point < " + mpUpper.getText() + ")";
			}
			dbAccessed = true;
		}
		else if (!mpLower.getText().isEmpty()) {
			if (dbAccessed) {
				query += " AND ";
			}
			query += "(melting_point > " + mpLower.getText() + ")";
			dbAccessed = true;
		}
		if (!dUpper.getText().isEmpty()) {
			if (dbAccessed) {
				query += " AND ";
			}
			if (!dLower.getText().isEmpty()) {
				query += "(density BETWEEN " + dLower.getText() + " AND " + dUpper.getText() + ")";
			}
			else {
				query += "(density < " + dUpper.getText() + ")";
			}
			dbAccessed = true;
		}
		else if (!dLower.getText().isEmpty()) {
			if (dbAccessed) {
				query += " AND ";
			}
			query += "(density > " + dLower.getText() + ")";
			dbAccessed = true;
		}
		if (!eUpper.getText().isEmpty()) {
			if (dbAccessed) {
				query += " AND ";
			}
			if (!eLower.getText().isEmpty()) {
				query += "(electronegativity BETWEEN " + eLower.getText() + " AND " + eUpper.getText() + ")";
			}
			else {
				query += "(electronegativity < " + eUpper.getText() + ")";
			}
			dbAccessed = true;
		}
		else if (!eLower.getText().isEmpty()) {
			if (dbAccessed) {
				query += " AND ";
			}
			query += "(electronegativity > " + eLower.getText() + ")";
			dbAccessed = true;
		}
		if (!amUpper.getText().isEmpty()) {
			if (dbAccessed) {
				query += " AND ";
			}
			if (!amLower.getText().isEmpty()) {
				query += "(atomic_mass BETWEEN " + amLower.getText() + " AND " + amUpper.getText() + ")";
			}
			else {
				query += "(atomic_mass < " + amUpper.getText() + ")";
			}
			dbAccessed = true;
		}
		else if (!amLower.getText().isEmpty()) {
			if (dbAccessed) {
				query += " AND ";
			}
			query += "(atomic_mass > " + amLower.getText() + ")";
			dbAccessed = true;
		}
		
		if (dbAccessed) {
			displayFilterResults(query);
		}
		
	}
	
	public void displayFilterResults(String query) {
		try {
			Connection connection = DriverManager.getConnection(jdbcUrl);
			
			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(query);
			
			while (result.next()) {
				resultText.append(result.getString("name") + "\n");
			}
		} catch (SQLException e) {
			System.out.println("Error: Can't connect to SQL database");
			e.printStackTrace();
		}
	}
	
	public void accessDatabase(String s) {
		
		try {
			Connection connection = DriverManager.getConnection(jdbcUrl);
			
			String sql = "SELECT * FROM elements";
			Statement statement = connection.createStatement();
			ResultSet result = statement.executeQuery(sql);

			while(!result.getString("button_text").equals(s)) {
				result.next();
			}
			
			String atomicNumber = result.getString("atomic_number");
			String name = result.getString("name");
			String group = result.getString("group");
			String boilingPoint = result.getString("boiling_point");
			String meltingPoint = result.getString("melting_point");
			String density = result.getString("density");
			String electronegativity = result.getString("electronegativity");
			String symbol = result.getString("symbol");
			String oxidationStates = result.getString("oxidation_states");
			String atomicMass = result.getString("atomic_mass");
			
			JOptionPane.showMessageDialog(frame, "Name: " + name + "\nAtomic number: " + atomicNumber
					+ "\nSymbol: " + symbol + "\nGroup: " + group + "\nBoiling point: " + boilingPoint
					+ " °C" + "\nMelting point: " + meltingPoint + " °C" + "\nDensity: " + density 
					+ " g/L" + "\nElectronegativity: " + electronegativity + "\nOxidation states: "
					+ oxidationStates + "\nAtomic mass: " + atomicMass + " Da"
					, "Information about " + name, JOptionPane.INFORMATION_MESSAGE);
			
		} catch (SQLException e) {
			System.out.println("Error: Can't connect to SQL database");
			e.printStackTrace();
		}
	}
}

